# Multicore_and_gpu
